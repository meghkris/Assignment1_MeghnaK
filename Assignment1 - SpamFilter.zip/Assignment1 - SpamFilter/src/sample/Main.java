package sample;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.*;
import java.util.*;
import java.lang.Math;
import java.util.List;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.DirectoryChooser;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Spam Filter");

        final String[] selectedDataDirectory = new String[1];

        // Getting the user's selected directory input
        Button button = new Button("Select Directory");
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                DirectoryChooser directoryChooser = new DirectoryChooser();
                directoryChooser.setInitialDirectory(new File("."));
                File selectedDirectory = directoryChooser.showDialog(primaryStage);
                selectedDataDirectory[0] = selectedDirectory.getAbsolutePath();
            }
        });

        Button button2 = new Button("Display Results");
        button2.setTranslateY(50);
        button2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                VBox root2 = new VBox();
                ScrollPane sp = new ScrollPane();

                if (selectedDataDirectory[0] == null) {
                    // If no directory was chosen no results will be displayed
                    Label label3 = new Label("No directory was chosen");
                    root2.getChildren().add(label3);
                } else {
                    // Setting up file paths and WordFileCounter instances for training spam filter phase
                    File trainHamDir = new File(selectedDataDirectory[0] + "\\train\\ham");
                    File trainSpamDir = new File(selectedDataDirectory[0] + "\\train\\spam");
                    WordFileCounter trainHamFreq = new WordFileCounter();
                    WordFileCounter trainSpamFreq = new WordFileCounter();
                    WordFileCounter wordDictionary = new WordFileCounter();

                    // Setting up file paths for testing spam filter phase
                    File testHamDir = new File(selectedDataDirectory[0] + "\\test\\ham");
                    File testSpamDir = new File(selectedDataDirectory[0] + "\\test\\spam");

                    // Creating list of TestFiles for the testing spam and ham files
                    List<TestFile> hamFiles = new ArrayList<>();
                    List<TestFile> spamFiles = new ArrayList<>();

                    try {
                        // Parsing files to first create list of unique words and then count the number of
                        // files that have that word in the respective training ham and spam folders
                        trainHamFreq.createDictionary(trainHamDir);
                        trainSpamFreq.createDictionary(trainSpamDir);

                        // Calculating the probability for each word that a file is spam given it contains
                        // the word and putting it in another WordFileCounter instance
                        wordDictionary.findSpamProbability(trainHamFreq, trainSpamFreq, trainHamDir, trainSpamDir);

                        // Going through each test ham file
                        System.out.println("Parsing files in" + testHamDir.getAbsolutePath());
                        double spamProb, prob;
                        // testHamFileFreq keeps track of the words encountered in a given file to ensure that the
                        // probability of a word is not multiplied multiple times if it is encountered multiple
                        // times in a given file.
                        WordFileCounter testHamFileFreq;
                        TestFile currentFile;
                        File[] content1 = testHamDir.listFiles();
                        for(File current: content1) {
                            spamProb = 0.;
                            testHamFileFreq = new WordFileCounter();
                            Scanner scanner = new Scanner(current);
                            currentFile = new TestFile(current.getName(), 0., "ham");
                            // scanning token by token
                            while (scanner.hasNext()) {
                                String token = scanner.next();
                                // If the current token is a valid word, the wordDictionary has this word, and the
                                // testHamFileFreq map does not contain the word meaning it is the first instance of
                                // the word in the file, the probability is updated and the word is added to the
                                // testHamFileFreq map.
                                if (currentFile.isValidWord(token) && wordDictionary.getWordFileCounts().containsKey(token) &&
                                        !testHamFileFreq.getWordFileCounts().containsKey(token)) {
                                    prob = wordDictionary.getWordFileCounts().get(token);
                                    prob = Math.log(1 - prob) - Math.log(prob);
                                    spamProb = spamProb + prob;
                                    testHamFileFreq.getWordFileCounts().put(token, 1.);
                                }
                            }
                            spamProb = 1 / (1 + Math.pow(Math.E, spamProb));
                            // Setting the spam probability for the current TestFile and then adding it to the list of
                            // "ham" type TestFiles
                            currentFile.setSpamProbability(spamProb);
                            hamFiles.add(currentFile);
                        }

                        // Going through each test spam file in a similar way to how it was done for the test ham files
                        System.out.println("Parsing files in" + testSpamDir.getAbsolutePath());
                        WordFileCounter testSpamFileFreq;
                        File[] content2 = testSpamDir.listFiles();
                        for(File current: content2) {
                            spamProb = 0.;
                            testSpamFileFreq = new WordFileCounter();
                            Scanner scanner = new Scanner(current);
                            currentFile = new TestFile(current.getName(), 0., "spam");
                            // scanning token by token
                            while (scanner.hasNext()) {
                                String token = scanner.next();
                                if (currentFile.isValidWord(token) && wordDictionary.getWordFileCounts().containsKey(token) &&
                                        !testSpamFileFreq.getWordFileCounts().containsKey(token)) {
                                    prob = wordDictionary.getWordFileCounts().get(token);
                                    prob = Math.log(1 - prob) - Math.log(prob);
                                    spamProb = spamProb + prob;
                                    testSpamFileFreq.getWordFileCounts().put(token, 1.);
                                }
                            }
                            spamProb = 1 / (1 + Math.pow(Math.E, spamProb));
                            currentFile.setSpamProbability(spamProb);
                            spamFiles.add(currentFile);
                        }
                    } catch(FileNotFoundException e) {
                        System.err.println("Invalid input dir: " + selectedDataDirectory[0]);
                        e.printStackTrace();
                    } catch(IOException e) {
                        e.printStackTrace();
                    }

                    // Counting the number of true negative guesses, true positive guesses, and
                    // false positive guesses needed to calculate the accuracy and precision of
                    // the program
                    int numTrueNegatives = 0;
                    int numTruePositives = 0;
                    int numFalsePositives = 0;

                    for (int i = 0; i < hamFiles.size(); i = i + 1) {
                        if (hamFiles.get(i).getSpamProbability() < 0.5) {
                            numTrueNegatives = numTrueNegatives + 1;
                        } else {
                            numFalsePositives = numFalsePositives + 1;
                        }
                    }

                    for (int i = 0; i < spamFiles.size(); i = i + 1) {
                        if (spamFiles.get(i).getSpamProbability() >= 0.5) {
                            numTruePositives = numTruePositives + 1;
                        } else {
                            numFalsePositives = numFalsePositives + 1;
                        }
                    }

                    // Adding all the TestFiles to one TestFile list
                    List<TestFile> allFiles = new ArrayList<>();
                    TestFile addFile;
                    for (int i = 0; i < hamFiles.size(); i = i + 1) {
                        addFile = new TestFile(hamFiles.get(i).getFilename(), hamFiles.get(i).getSpamProbability(),
                                                hamFiles.get(i).getActualClass());
                        allFiles.add(addFile);
                    }
                    for (int i = 0; i < spamFiles.size(); i = i + 1) {
                        addFile = new TestFile(spamFiles.get(i).getFilename(), spamFiles.get(i).getSpamProbability(),
                                                spamFiles.get(i).getActualClass());
                        allFiles.add(addFile);
                    }

                    // Calculating the accuracy and precision values
                    int numFiles = hamFiles.size() + spamFiles.size();
                    double accuracy = (double) (numTruePositives + numTrueNegatives) / numFiles;
                    double precision = (double) numTruePositives / (numFalsePositives + numTruePositives);

                    // Setting up the table to display all the TestFiles
                    TableView<TestFile> table = new TableView<>();
                    ObservableList<TestFile> fileData = FXCollections.observableList(allFiles);

                    TableColumn<TestFile, String> column1 = new TableColumn<>("File Name");
                    column1.setCellValueFactory(new PropertyValueFactory<>("filename"));

                    TableColumn<TestFile, Double> column2 = new TableColumn<>("Spam Probability");
                    column2.setCellValueFactory(new PropertyValueFactory<>("spamProbRounded"));

                    TableColumn<TestFile, String> column3 = new TableColumn<>("Actual Class");
                    column3.setCellValueFactory(new PropertyValueFactory<>("actualClass"));

                    table.getColumns().add(column1);
                    table.getColumns().add(column2);
                    table.getColumns().add(column3);
                    table.setItems(fileData);

                    // Creating labels to display the accuracy and precision values
                    Label label1 = new Label("Accuracy: " + accuracy);
                    Label label2 = new Label("Precision: " + precision);

                    root2.getChildren().add(label1);
                    root2.getChildren().add(label2);
                    root2.getChildren().add(table);

                    root2.setSpacing(10);
                    root2.setPrefWidth(515);
                    root2.setAlignment(Pos.CENTER);
                    root2.setPadding(new Insets(10, 10, 10, 10));
                }

                sp.setContent(root2);
                Stage secondWindow = new Stage();
                secondWindow.setTitle("Results");
                secondWindow.setScene(new Scene(sp, 520, 500));
                secondWindow.show();
            }
        });

        StackPane root = new StackPane();
        root.getChildren().add(button);
        root.getChildren().add(button2);
        primaryStage.setScene(new Scene(root, 300, 250));
        primaryStage.show();
    }

    public static void main(String[] args) {
        System.out.println("Starting spam filter...");
        launch(args);
    }
}
