package sample;

import java.io.*;
import java.util.*;

public class WordFileCounter{

    private Map<String, Double> wordFileCounts;

    public WordFileCounter() {
        wordFileCounts = new TreeMap<>();
    }

    public Map<String, Double> getWordFileCounts() {
        return this.wordFileCounts;
    }

    // This method fills the map for the instance of WordFileCounter with the list of unique words
    // that exist in all files in the specified directory and the number of files in the directory
    // that contain each word.
    public void createDictionary(File file) throws IOException {
        if (file.isDirectory()) {
            System.out.println("Parsing files in" + file.getAbsolutePath());
            int num = file.list().length;
            // Parse each file inside the directory
            File[] content = file.listFiles();
            WordFileCounter keepTrack;
            for (int i = 1; i <= num; i = i + 1) {
                keepTrack = new WordFileCounter();
                Scanner scanner = new Scanner(content[i - 1]);
                // Scanning token by token
                while (scanner.hasNext()) {
                    String token = scanner.next();
                    if (isValidWord(token)) {
                        // If the word is a valid word and the map does not contain it, the word
                        // is added to the map. The keepTrack map is updated for the individual
                        // file as well for the given word.
                        if (!this.wordFileCounts.containsKey(token)) {
                            this.wordFileCounts.put(token, 1.);
                            keepTrack.wordFileCounts.put(token, 0.);
                        } else {
                            // If the word is a valid word and the map contains it, but the keepTrack
                            // map for the file doesn't, the count is updated in the map, and the word
                            // is added to the keepTrack map to avoid multiple counts of a single word
                            // in one file.
                            if (!keepTrack.wordFileCounts.containsKey(token)) {
                                this.wordFileCounts.put(token, this.wordFileCounts.get(token) + 1.);
                                keepTrack.wordFileCounts.put(token, 0.);
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean isValidWord(String word) {
        String allLetters = "^[a-zA-Z]+$";
        // returns true if the word is composed by only letters otherwise returns false;
        return word.matches(allLetters);
    }

    // This method uses the unique ham words and the number of ham files that contain each word, and the
    // unique spam words and the number of spam files that contain each word obtained from the training
    // phase to create a full wordDictionary which is an instance of WordFileCounter whose map contains
    // all the words that appeared in the files and the probability that a file is spam given it has the word.
    public void findSpamProbability(WordFileCounter ham, WordFileCounter spam, File hamDir, File spamDir) {
        int numHamFiles = hamDir.list().length;
        int numSpamFiles = spamDir.list().length;
        double hamProb, spamProb, finalProb;

        // Adding all the words to the wordDictionary found in the training phase
        for (String word: ham.wordFileCounts.keySet()) {
                this.wordFileCounts.put(word, 0.);
        }

        for (String word: spam.wordFileCounts.keySet()) {
            if (!this.wordFileCounts.containsKey(word)) {
                this.wordFileCounts.put(word, 0.);
            }
        }

        for (String word: this.wordFileCounts.keySet()) {
            // Getting the ham probability and spam probability for each word and then calculating the final
            // probability that a file is spam given it contains the word.
            if (ham.wordFileCounts.containsKey(word)) { hamProb = ham.wordFileCounts.get(word) / numHamFiles; }
            else { hamProb = 0.; }

            if (spam.wordFileCounts.containsKey(word)) { spamProb = spam.wordFileCounts.get(word) / numSpamFiles; }
            else { spamProb = 0.; }

            finalProb = spamProb / (hamProb + spamProb);

            // To avoid getting a NaN error, the final probability is adjusted accordingly.
            if (finalProb < 0.01) { finalProb = 0.01; }
            else if (finalProb > 0.99) { finalProb = 0.99; };

            this.wordFileCounts.put(word, finalProb);
        }
    }
}
